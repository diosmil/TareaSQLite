package com.example.gestor_de_nota_sqlite;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class BDcliente extends SQLiteOpenHelper {

    String crea="Create table cliente( id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT )";

    public BDcliente(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL(crea);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("Drop table if exists cliente" );
        db.execSQL(crea);

    }
}
